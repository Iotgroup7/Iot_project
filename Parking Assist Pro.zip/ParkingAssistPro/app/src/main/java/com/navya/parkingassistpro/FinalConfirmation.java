package com.navya.parkingassistpro;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class FinalConfirmation extends AppCompatActivity {

    TextView timerText;
    private CountDownTimer countDownTimer = null;
    public boolean timeRunning;
    public static final long START_TIME_IN_MILLIS = 60000;
    private long timeLeftInMillis = START_TIME_IN_MILLIS;
    Button startBooking, cancelBooking;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_confirmation);
        timerText = findViewById(R.id.timer_text_view);
        startBooking = findViewById(R.id.start_booking_button);
        startStop();
cancelBooking = findViewById(R.id.cancel_booking);

cancelBooking.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        countDownTimer.cancel();
        timerText.setText("Go Back to the previous screen to start again");
    }
});

        startBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(FinalConfirmation.this, "Navigation begins", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                        Uri.parse("geo:0,0?q=39.035766,-94.581085"));
                startActivity(intent);
            }
        });

    }

    private void startStop() {
        if (timeRunning){
            stopTimer();
        }
        else {
            startTimer();
        }
    }


    private void startTimer() {


       countDownTimer =  new CountDownTimer(300000, 1000) {

            @SuppressLint("SetTextI18n")
            public void onTick(long millisUntilFinished) {
                timerText.setText(" " + ((millisUntilFinished / 1000)/60) + ":" + ((millisUntilFinished / 1000)%60));
            }

            public void onFinish() {
                timerText.setText("done!");
            }
        };
      countDownTimer.start();
    }

    private void stopTimer() {

        countDownTimer.cancel();
    }

}