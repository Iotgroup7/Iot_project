package com.navya.parkingassistpro;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.navya.parkingassistpro.databinding.ActivityMapsBinding;

import java.util.Objects;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
int LOCATION_REFRESH_TIME = 1500;
int LOCATION_REFRESH_DISTANCE = 500;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(39.063139, -94.579032);
        LatLng cherry_parking_structure = new LatLng(39.035766, -94.581085);
        LatLng thirty_three = new LatLng(39.038903, -94.572697);
        LatLng ninety_six = new LatLng(39.038901, -94.572352);
        LatLng rockhill = new LatLng(39.036539, -94.576900);
        LatLng three = new LatLng(39.035389, -94.576446);
        LatLng oak_street_5001 = new LatLng(39.035637, -94.581394);
        LatLng oak_street_5120 = new LatLng(39.033965, -94.583465);
        LatLng twenty_four = new LatLng(39.034188, -94.581664);
        LatLng rockhill_structure = new LatLng(39.032025, -94.576162);
        LatLng a_fourty_four = new LatLng(39.031218, -94.577512);
        LatLng time_building = new LatLng(39.040773, -94.593396);
        LatLng central_parking = new LatLng(39.041801, -94.590711);
        LatLng giralda_parking = new LatLng(39.041427, -94.588642);



        Objects.requireNonNull(mMap.addMarker(new MarkerOptions().position(sydney).title("New bern Apartment")))
                .setIcon(BitmapFromVector(getApplicationContext(), R.drawable.time_icon));
        mMap.addMarker(new MarkerOptions().position(cherry_parking_structure).title("Cherry Parking structure")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(thirty_three).title("UMKC parking lot 33")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(ninety_six).title("UMKC parking lot 96")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(rockhill).title("Rockhill Parking")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(three).title("UMKC parking lot 3")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(oak_street_5001).title("Oak Street 5001")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(oak_street_5120).title("Oak street 5120")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(twenty_four).title("UMKC parking lot 24")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(rockhill_structure).title("Rockhill structure parking")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(a_fourty_four).title("UMKC parking lot A-44")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(time_building).title("Time building parking")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(central_parking).title("Central Parking")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));
        mMap.addMarker(new MarkerOptions().position(giralda_parking).title("Girlada Parking")).setIcon(BitmapFromVector(getApplicationContext(), R.drawable.car_icon));




        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker) {
                startActivity(new Intent(getApplicationContext(), ParkingLot.class));
                return false;
            }
        });
    }

    private BitmapDescriptor BitmapFromVector(Context context, int vectorResId) {
        // below line is use to generate a drawable.
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);

        // below line is use to set bounds to our vector drawable.
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());

        // below line is use to create a bitmap for our
        // drawable which we have added.
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);

        // below line is use to add bitmap in our canvas.
        Canvas canvas = new Canvas(bitmap);

        // below line is use to draw our
        // vector drawable in canvas.
        vectorDrawable.draw(canvas);

        // after generating our bitmap we are returning our bitmap.
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

}