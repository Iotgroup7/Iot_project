package com.navya.parkingassistpro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

public class ParkingLot extends AppCompatActivity {
ToggleButton a3,b2,a5,a8,b5,b6;
Button startBooking;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_lot);
        a3 = findViewById(R.id.a_three_slot);
        b2 = findViewById(R.id.b_two_slot);
        a5 = findViewById(R.id.a_five_slot);
        a8 = findViewById(R.id.a_eight_slot);
        b5 = findViewById(R.id.b_five_slot);
        b6 = findViewById(R.id.b_six_slot);
        startBooking = findViewById(R.id.next_step_button);



        CompoundButton.OnCheckedChangeListener changeChecker = new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    if (buttonView != a3) {
                        a3.setChecked(false);
                        a3.setBackgroundColor(Color.GREEN);
                    }
                    else{
                        a3.setBackgroundColor(Color.YELLOW);

                    }
                    if (buttonView != b2) {
                        b2.setChecked(false);
                        b2.setBackgroundColor(Color.GREEN);
                    }
                    else{
                        b2.setBackgroundColor(Color.YELLOW);
                    }
                    if (buttonView != a5) {
                        a5.setChecked(false);
                        a5.setBackgroundColor(Color.GREEN);
                    }
                    else{
                        a5.setBackgroundColor(Color.YELLOW);
                    }
                    if (buttonView != b5) {
                        b5.setChecked(false);
                        b5.setBackgroundColor(Color.GREEN);
                    }
                    else{
                        b5.setBackgroundColor(Color.YELLOW);
                    }
                    if (buttonView != a8) {
                        a8.setChecked(false);
                        a8.setBackgroundColor(Color.GREEN);
                    }
                    else{
                        a8.setBackgroundColor(Color.YELLOW);
                    }
                    if (buttonView != b6) {
                        b6.setChecked(false);
                        b6.setBackgroundColor(Color.GREEN);
                    }
                    else{
                        b6.setBackgroundColor(Color.YELLOW);
                    }
            }}};

        a3.setOnCheckedChangeListener(changeChecker);
        b2.setOnCheckedChangeListener(changeChecker);
        a5.setOnCheckedChangeListener(changeChecker);
        b5.setOnCheckedChangeListener(changeChecker);
        a8.setOnCheckedChangeListener(changeChecker);
        b6.setOnCheckedChangeListener(changeChecker);

        startBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                startActivity(new Intent(getApplicationContext(),FinalConfirmation.class));
            }
        });
    }
}